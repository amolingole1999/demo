package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.model.Student;
import com.app.service.StudentServiceI;

@Controller
public class HomeController {
		@Autowired
	StudentServiceI ssi;
	@RequestMapping(value = "/")
	public String preLogin() {
		return "login";
	}
	
	@RequestMapping(value = "/register")
	public String preRegister() {
		return "register";
	}
	@RequestMapping(value = "/save")
	public String saveStudent(@ModelAttribute Student s) {
		ssi.saveStudent(s);
		return "login";
	}
	
	
	
	
	
	
	
	
	@RequestMapping(value = "/login")
	public String logincheck(@ModelAttribute Student s,Model m) {
		if(s.getUsername().equals("ADMIN") && s.getPassword().equals("ADMIN")) {
			List<Student> list=ssi.getStudents();
			m.addAttribute("data", list);
			return "success";
		}
		else {
			List<Student> list=ssi.logincheck(s.getUsername(),s.getPassword());
			if(!list.isEmpty()) {
				m.addAttribute("data", list);
				return "success";
			}
			else {
				
				return "login";
			}
			
			
		}
		
	}
	@RequestMapping(value = "/delete")
	public String deleteStudent(@RequestParam int rollno,Model m) {
		System.out.println(rollno);
		    ssi.deleteStudent(rollno);
		       List<Student> list=ssi.getStudents();
		       m.addAttribute("data", list);
		return "success";
	}
	@RequestMapping(value = "/edit")
	public String editStudent(@RequestParam int rollno,Model m) {
		System.out.println("in edit");
		    Student s=  ssi.editStudent(rollno);
		    System.out.println(s);
		    if(s!=null) {
		    	 m.addAttribute("data", s);
		    }
		    System.out.println("open edit page");
		return "edit";
	}
	
	@RequestMapping(value = "/update")
	public String updateStudent(@ModelAttribute Student s,Model m) {
		ssi.updateStudent(s);
		List<Student> list=ssi.getStudents();
		m.addAttribute("data", list);
	return "success";
		
	}
	
}
