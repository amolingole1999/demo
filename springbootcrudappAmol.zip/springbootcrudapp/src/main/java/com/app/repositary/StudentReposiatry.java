package com.app.repositary;



import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.app.model.Student;
@Repository
public interface StudentReposiatry extends CrudRepository<Student,Integer>
{
       // custom method
	public List<Student> findByUsernameAndPassword(String username,String password);
}
