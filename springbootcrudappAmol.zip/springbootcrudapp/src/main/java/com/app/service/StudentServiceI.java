package com.app.service;

import java.util.List;

import com.app.model.Student;

public interface StudentServiceI {
	public void saveStudent(Student s);
	public List<Student> getStudents();
	public List<Student> logincheck(String username,String password);
	public void deleteStudent(int rollno);
	public Student editStudent(int rollno);
	public void updateStudent(Student s);

}
