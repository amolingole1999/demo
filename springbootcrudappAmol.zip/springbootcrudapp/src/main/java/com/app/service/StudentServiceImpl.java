package com.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.model.Student;
import com.app.repositary.StudentReposiatry;
@Service
public class StudentServiceImpl implements StudentServiceI{
 @Autowired
	StudentReposiatry sr;
	@Override
	public void saveStudent(Student s) {
         sr.save(s);
		
	}
	@Override
	public List<Student> getStudents() {
		
		return (List<Student>) sr.findAll();
	}
	@Override
	public List<Student> logincheck(String username, String password) {
		   
		
		      
		return sr.findByUsernameAndPassword(username, password);
	}
	@Override
	public void deleteStudent(int rollno) {
		
		sr.deleteById(rollno);
	}
	@Override
	public Student editStudent(int rollno) {
		Optional<Student> op=sr.findById(rollno);
		     if(op.isPresent()) {
		    	  Student s= op.get(); 
		    	  return s;
		     }
		     else {
		    	 return null;
		     }
	
	}
	
	@Override
	public void updateStudent(Student s) {
		sr.save(s);
		
	}
}
